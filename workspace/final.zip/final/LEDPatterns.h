void setLEDLetter(uint16_t * letter);
void displayLEDletter(uint16_t num);
